#!/bin/bash
cd /var/app/staging
sudo -u webapp npm install sharp
sudo -u webapp npm install @nestjs/cli