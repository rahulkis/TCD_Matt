export enum tcdUpdateCategoryEnum {
  Category1 = 'Category 1',
  Category2 = 'Category 2',
  Category3 = 'Category 3',
}
