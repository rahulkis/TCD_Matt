export enum DateFilterEnum {
    SIX_MONTHS = 6,
    THIS_MONTH = 1,
    LAST_30_DAYS = 2,
    LAST_MONTH = 4,
    THREE_MONTHS = 5,
    CUSTOM_RANGE = 0,
}