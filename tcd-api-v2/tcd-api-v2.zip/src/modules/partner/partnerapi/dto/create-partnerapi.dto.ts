export class CreatePartnerapiDto {}
